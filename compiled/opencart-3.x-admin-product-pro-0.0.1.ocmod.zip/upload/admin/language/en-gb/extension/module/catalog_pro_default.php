<?php
// package info
$_['menu_parent']            = '<span class="label label-success">PRO</span> CatalogPRO';
$_['submenu_config']         = 'Settings';
$_['submenu_product']        = 'Products';