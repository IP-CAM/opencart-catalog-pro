<?php
// package info
$_['menu_parent']            = '<span class="label label-success">PRO</span> Каталог';
$_['submenu_config']         = 'Настройки';
$_['submenu_product']        = 'Товары';